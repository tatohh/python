"""
Se pretende crear una aplicación que haga exámenes tipo test similares a como los realiza la
plataforma Moodle con una sola respuesta.

Las preguntas están almacenas en un fichero de preguntas.
Cada pregunta está separada de la siguiente con una línea cuyo valor es “---”.

Autor: Hector Cevallos Paredes
"""
import json


class Question:
    def __init__(self, name, statement, options, points=1):
        self.__name = name
        self.__statement = statement
        self.__options = options
        self.__points = points

    @property
    def name(self):
        return self.__name

    @property
    def statement(self):
        return self.__statement

    @property
    def options(self):
        return self.__options

    @property
    def points(self):
        return self.__points

    def get_score(self, chosen_option):
        return self.__points * self.__options[chosen_option][1]

# Function para cargar las preguntas desde el archivo json.


def load_questions(filename):
    with open(filename, "r") as file:
        data = json.load(file)

    return [Question(q["name"], q["statement"], q["options"], q["points"]) for q in data]

    # Funcion para crear el test


def take_exam(questions):
    score = 0

    for i, question in enumerate(questions):
        print(f"Pregunta {i + 1}. {question.statement}")
        for j, option in enumerate(question.options):
            print(f"{j + 1}. {option[0]}")

        chosen_option = input("Indique la opción correcta (Pulse Intro para dejarla en blanco): ")

        if chosen_option:
            chosen_option = int(chosen_option) - 1
            score += question.get_score(chosen_option)

    return score

    # Funcion para ejecutar el test


def main():
    questions = load_questions("questions.json")
    score = take_exam(questions)
    print(f"Puntuación obtenida: {score} puntos.")


if __name__ == "__main__":
    main()


"""
Version 3 prueba

import xml.etree.ElementTree as ET

def load_questions_xml(filename):
    tree = ET.parse(filename)
    root = tree.getroot()

    questions = []

    for question_node in root.findall("question"):
        name = question_node.get("name", "")
        points = float(question_node.get("base_score", "1"))

        statement = question_node.find("statement").text.strip()

        options = []
        for option_node in question_node.findall("options/option"):
            option_text = option_node.text.strip()
            weight = float(option_node.get("weight", "0"))
            options.append((option_text, weight))

        questions.append(Question(name, statement, options, points))

    return questions

# Función principal actualizada para cargar las preguntas desde un archivo XML
def main():
    questions = load_questions_xml("questions.xml")
    score = take_exam(questions)
    print(f"Puntuación obtenida: {score} puntos.")
    
    No olvides actualizar la llamada a load_questions en la función main por load_questions_xml. 
    Ahora el código debería funcionar correctamente con archivos XML como el que proporcionaste.
"""