"""
Empezaremos creando una clase para modelar las preguntas, los objetos de esta clase (Question)
tendrán los siguientes atributos:
• Nombre de la pregunta.
• Enunciado.
• Elecciones (posibles respuestas): lista de tuplas (texto respuesta, calificación en % [0,1]).
• Puntuación base de la pregunta (por defecto 1).

Autor: Héctor Cevallos Paredes

"""

from typeguard import typechecked


@typechecked
class Question:
    def __init__(self, name: str, statement: str, answers: list[tuple[str, float]], score: float = 1):
        self.__name = name
        self.__statement = statement
        self.__answers = answers
        self.__score = score

    def reply(self, answers: str):
        for i in self.__answers:
            if answers in i[0]:
                return i[1] * self.__score
        raise ValueError("Respuesta no válida")

    @property
    def name(self):
        return self.__name

    @property
    def statement(self):
        return self.__statement

    @property
    def answers(self):
        return self.__answers

    @property
    def score(self):
        return self.__score

    @property
    def correct_answer(self):
        for i in self.__answers:
            if i[1] + 1:
                return i[0]


"""
Programa que prueba la clase question con las indicaciones dadas en el ejercicio teniendo en cuenta el fichero de muestra
ejemplo_test.txt
"""
questions_number = int(input("Introduce el número de preguntas que tendrá el TEST: "))
questions = []


def make_test():
    for i in range(questions_number):
        tmp_name = input(f"Ingrese el nombre para la pregunta número {i + 1}: ")
        tmp_statement = []
        while "." not in tmp_statement:
            tmp_statement.append(input(f"Ingrese el enunciado para la pregunta número {i + 1} (. para finalizar): "))
        tmp_statement = "\n".join(tmp_statement)
        tmp_answer = []
        for n in range(4):
            tmp_answer_text = input(f"Ingrese el texto para la respuesta número {n + 1}: ")
            tmp_answer_calification = float(
                input(f"Ingrese el porcentaje (entre '-1' y '+1') para la respuesta número {n + 1}: "))
            tmp_answer.append((tmp_answer_text, tmp_answer_calification))

        questions.append(Question(tmp_name, tmp_statement, tmp_answer))


def do_test():
    nota = 0
    nota_maxima = 0
    for q in range(len(questions)):
        print(f"Pregunta {q + 1}. {questions[q].statement}")
        for f in range(len(questions[q].answers)):
            print(f"{f + 1}. {questions[q].answers[0]}")
        input_value = int(input("Indique la opción correcta (Pulse Intro para dejarla en blanco): "))
        if 0 < input_value > len(questions[q].answers):
            nota += questions[input_value].answers[1] * questions[input_value].score
        nota_maxima += questions[input_value].score
    print(f"Puntuación obtenida: {(nota * 10) / nota_maxima} puntos.")


make_test()
do_test()