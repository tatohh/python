"""
Segunda version de la clase Question, con las siguientes indicaciones. Segunda versión.
Las preguntas están almacenas en un fichero de preguntas.
Cada pregunta está separada de la siguiente con una línea cuyo valor es “---”.
La sintaxis de cada pregunta es:
<Nombre de la pregunta>
<Enunciado de la pregunta> puede haber varias líneas, el final se delimita con una línea que tiene
un punto (“.”)>.
<Elecciones con su calificación> ocupan dos líneas.
Se adjunta un ejemplo de este archivo.

Autor: Hector Cevallos Paredes
"""

from typeguard import typechecked


@typechecked
class Question:
    def __init__(self, name: str, statement: str, answers: list[tuple[str, float]], score: float = 1):
        self.__name = name
        self.__statement = statement
        self.__answers = answers
        self.__score = score

    def reply(self, answers: str):
        for i in self.__answers:
            if answers in i[0]:
                return i[1] * self.__score
        raise ValueError("Respuesta no válida")

    @property
    def name(self):
        return self.__name

    @property
    def statement(self):
        return self.__statement

    @property
    def answers(self):
        return self.__answers

    @property
    def score(self):
        return self.__score

    @property
    def correct_answer(self):
        for i in self.__answers:
            if i[1] + 1:
                return i[0]


def read_questions(filename: str) -> list[Question]:
    with open(filename, "r", encoding="utf-8") as file:
        lines = file.readlines()

    questions = []
    name = ""
    statement = ""
    answers = []

    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line == "---":
            questions.append(Question(name, statement, answers))
            name = ""
            statement = ""
            answers = []
        elif not name:
            name = line
        elif not statement:
            statement = line
        elif line.endswith("."):
            statement += "\n" + line
        else:
            letter, score = line.split(", ")
            answers.append((letter, float(score)))

    questions.append(Question(name, statement, answers))

    return questions


if __name__ == '__main__':
    questions = read_questions("preguntas.txt")

    for question in questions:
        print(question.statement)
        answer = input("Respuesta: ")
        try:
            score = question.reply(answer)
            print("Respuesta correcta. Puntaje:", score)
        except ValueError:
            print("Respuesta incorrecta.")
